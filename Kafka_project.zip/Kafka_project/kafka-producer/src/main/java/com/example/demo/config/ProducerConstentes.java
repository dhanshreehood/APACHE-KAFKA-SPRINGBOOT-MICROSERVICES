package com.example.demo.config;

public class ProducerConstentes {
	public static final String LOCATION_TOPIC_NAME = "location-update-topic";
}
